use std::collections::BTreeMap;
use crate::TeaqlRuntime;
use crate::Q;
use teaql_core::Entity;
use crate::request_support::TeaqlUserContextExt;
use teaql_runtime::AuditedSaveExt;

pub trait IntoU64 {
    fn into_u64(self) -> u64;
}

impl IntoU64 for u64 {
    fn into_u64(self) -> u64 {
        self
    }
}

impl IntoU64 for Option<&teaql_core::Value> {
    fn into_u64(self) -> u64 {
        self.and_then(|v| v.try_u64()).unwrap_or_default()
    }
}

#[derive(Debug, Copy, Clone)]
pub enum SampleDataScale {
    Tiny,
    Small,
    Medium,
}

pub struct SampleDataPlan {
    pub scale: SampleDataScale,
    pub seed: u64,
}

impl SampleDataPlan {
    pub fn small() -> Self {
        Self {
            scale: SampleDataScale::Small,
            seed: 0,
        }
    }
}

pub struct SampleDataReport {
    pub generated: BTreeMap<&'static str, usize>,
    pub skipped: Vec<SampleDataSkipped>,
}

pub struct SampleDataSkipped {
    pub entity: &'static str,
    pub reason: String,
}

pub struct SampleDataState {
    pub plan: SampleDataPlan,
    pub references: BTreeMap<&'static str, Vec<u64>>,
    pub generated: BTreeMap<&'static str, usize>,
    pub skipped: Vec<SampleDataSkipped>,
}

impl SampleDataState {
    pub fn new(plan: SampleDataPlan) -> Self {
        Self {
            plan,
            references: BTreeMap::new(),
            generated: BTreeMap::new(),
            skipped: Vec::new(),
        }
    }

    pub fn add_reference(&mut self, entity: &'static str, id: u64) {
        self.references.entry(entity).or_default().push(id);
    }

    pub fn ids(&self, entity: &'static str) -> &[u64] {
        self.references.get(entity).map(|v| v.as_slice()).unwrap_or(&[])
    }

    pub fn pick_id(&self, entity: &'static str, salt: usize) -> Option<u64> {
        let ids = self.ids(entity);
        if ids.is_empty() {
            None
        } else {
            Some(ids[salt % ids.len()])
        }
    }

    pub fn pick_unused_id(&self, entity: &'static str, salt: usize, used: &std::collections::HashSet<u64>) -> Option<u64> {
        let ids = self.ids(entity);
        if ids.is_empty() {
            return None;
        }

        let best_id = ids[salt % ids.len()];
        if !used.contains(&best_id) {
            return Some(best_id);
        }

        for id in ids {
            if !used.contains(id) {
                return Some(*id);
            }
        }

        Some(best_id)
    }

    pub fn record_generated(&mut self, entity: &'static str) {
        *self.generated.entry(entity).or_default() += 1;
    }

    pub fn record_skipped(&mut self, entity: &'static str, reason: String) {
        self.skipped.push(SampleDataSkipped { entity, reason });
    }

    pub fn into_report(self) -> SampleDataReport {
        SampleDataReport {
            generated: self.generated,
            skipped: self.skipped,
        }
    }
}










pub async fn generate_sample_data<C>(
    ctx: &C,
    plan: SampleDataPlan,
) -> Result<SampleDataReport, String>
where
    C: TeaqlRuntime + ?Sized + crate::TeaqlRepositoryProvider,
{
    log::info!("Starting sample data generation. Scale: {:?}, Seed: {}", plan.scale, plan.seed);
    let mut state = SampleDataState::new(plan);

    load_root_platforms(ctx, &mut state).await?; //depth: 0

    load_constant_task_statuses(ctx, &mut state).await?;


    ctx.user_context().transaction_data(|| async {
        Box::pin(generate_platforms(ctx, &mut state)).await.map_err(|e| {
            teaql_runtime::DataServiceError::Runtime(teaql_runtime::RuntimeError::Graph(e))
        })
    }).await.map_err(|e| e.to_string())?;

    ctx.user_context().transaction_data(|| async {
        Box::pin(generate_tasks(ctx, &mut state)).await.map_err(|e| {
            teaql_runtime::DataServiceError::Runtime(teaql_runtime::RuntimeError::Graph(e))
        })
    }).await.map_err(|e| e.to_string())?;

    ctx.user_context().transaction_data(|| async {
        Box::pin(generate_task_execution_logs(ctx, &mut state)).await.map_err(|e| {
            teaql_runtime::DataServiceError::Runtime(teaql_runtime::RuntimeError::Graph(e))
        })
    }).await.map_err(|e| e.to_string())?;

    let report = state.into_report();
    log::info!("Sample data generation completed successfully. Generated: {} tables, Skipped: {} tables.", report.generated.len(), report.skipped.len());
    Ok(report)
}

async fn load_root_platforms<C>(
    ctx: &C,
    state: &mut SampleDataState,
) -> Result<(), String>
where
    C: TeaqlRuntime + ?Sized + crate::TeaqlRepositoryProvider,
{
    let list = Q::platforms().purpose("Init Sample Data").execute_for_list(ctx).await.unwrap_or_default();
    for item in list {
        state.add_reference("Platform", item.id().into_u64());
    }
    Ok(())
}

async fn load_constant_task_statuses<C>(
    ctx: &C,
    state: &mut SampleDataState,
) -> Result<(), String>
where
    C: TeaqlRuntime + ?Sized + crate::TeaqlRepositoryProvider,
{
    let list = Q::task_statuses().purpose("Init Sample Data").execute_for_list(ctx).await.unwrap_or_default();
    for item in list {
        state.add_reference("Task Status", item.id().into_u64());
    }
    Ok(())
}

async fn generate_platforms<C>(
    ctx: &C,
    state: &mut SampleDataState,
) -> Result<(), String>
where
    C: TeaqlRuntime + ?Sized + crate::TeaqlRepositoryProvider,
{

    let object_fields_count = 0;
    let base_fanout = std::cmp::max(1, object_fields_count) * 20;

    let fanout = match state.plan.scale {
        SampleDataScale::Tiny => base_fanout,
        SampleDataScale::Small => base_fanout * 5,
        SampleDataScale::Medium => base_fanout * 50,
    };

    log::info!("Generating sample data for Platform (expected: {})...", fanout);

    for i in 0..fanout {
        let mut entity = Q::platforms().purpose("Init Sample Data").new_entity(ctx);
        let mut used_refs: std::collections::HashSet<u64> = std::collections::HashSet::new();

                entity.update_name(format!("{} {}", "Robot System", i + 1));

                {
                    let days = ((i as u64 + state.plan.seed) % (365 * 3)) as i64;
                    let past = chrono::Utc::now().naive_utc() - chrono::Duration::try_days(days).unwrap_or_default();
                    entity.update_founded(past.format("%Y-%m-%d").to_string());
                }

                entity.update_user_email(format!("{} {}", "Sample", i + 1));



        let entity = entity.audit_as("Init Sample Data").save(ctx.user_context()).await.map_err(|e| e.to_string())?;

        state.record_generated("Platform");

        if i % 20 == 0 {
            log::info!("Generating Platform: {}/{}", i, fanout);
        }

        state.add_reference("Platform", entity.id().into_u64());
    }

    log::info!("Successfully generated sample records for Platform.");
    Ok(())
}
async fn generate_tasks<C>(
    ctx: &C,
    state: &mut SampleDataState,
) -> Result<(), String>
where
    C: TeaqlRuntime + ?Sized + crate::TeaqlRepositoryProvider,
{
        if state.ids("Task Status").is_empty() {
            state.record_skipped("Task", "Required dependency Task Status is missing in reference pool".to_string());
            log::info!("Skipped generating Task: Required dependency Task Status is missing in reference pool.");
            return Ok(());
        }
        if state.ids("Platform").is_empty() {
            state.record_skipped("Task", "Required dependency Platform is missing in reference pool".to_string());
            log::info!("Skipped generating Task: Required dependency Platform is missing in reference pool.");
            return Ok(());
        }

    let object_fields_count = 0 + 1 + 1;
    let base_fanout = std::cmp::max(1, object_fields_count) * 20;

    let fanout = match state.plan.scale {
        SampleDataScale::Tiny => base_fanout,
        SampleDataScale::Small => base_fanout * 5,
        SampleDataScale::Medium => base_fanout * 50,
    };

    log::info!("Generating sample data for Task (expected: {})...", fanout);

    for i in 0..fanout {
        let mut entity = Q::tasks().purpose("Init Sample Data").new_entity(ctx);
        let mut used_refs: std::collections::HashSet<u64> = std::collections::HashSet::new();

                if let Some(ref_id) = state.pick_unused_id("Task Status", i as usize, &used_refs) {
                    entity.update_status_id(ref_id);
                    used_refs.insert(ref_id);
                } else {
                    // Optional relation was missing in reference pool
                }
                if let Some(ref_id) = state.pick_unused_id("Platform", i as usize, &used_refs) {
                    entity.update_platform_id(ref_id);
                    used_refs.insert(ref_id);
                } else {
                    // Optional relation was missing in reference pool
                }
                entity.update_name(format!("{} {}", "Task Name|[1,200]", i + 1));



        let entity = entity.audit_as("Init Sample Data").save(ctx.user_context()).await.map_err(|e| e.to_string())?;

        state.record_generated("Task");

        if i % 20 == 0 {
            log::info!("Generating Task: {}/{}", i, fanout);
        }

        state.add_reference("Task", entity.id().into_u64());
    }

    log::info!("Successfully generated sample records for Task.");
    Ok(())
}
async fn generate_task_execution_logs<C>(
    ctx: &C,
    state: &mut SampleDataState,
) -> Result<(), String>
where
    C: TeaqlRuntime + ?Sized + crate::TeaqlRepositoryProvider,
{
        if state.ids("Task").is_empty() {
            state.record_skipped("Task Execution Log", "Required dependency Task is missing in reference pool".to_string());
            log::info!("Skipped generating Task Execution Log: Required dependency Task is missing in reference pool.");
            return Ok(());
        }

    let object_fields_count = 0 + 1;
    let base_fanout = std::cmp::max(1, object_fields_count) * 20;

    let fanout = match state.plan.scale {
        SampleDataScale::Tiny => base_fanout,
        SampleDataScale::Small => base_fanout * 5,
        SampleDataScale::Medium => base_fanout * 50,
    };

    log::info!("Generating sample data for Task Execution Log (expected: {})...", fanout);

    for i in 0..fanout {
        let mut entity = Q::task_execution_logs().purpose("Init Sample Data").new_entity(ctx);
        let mut used_refs: std::collections::HashSet<u64> = std::collections::HashSet::new();

                if let Some(ref_id) = state.pick_unused_id("Task", i as usize, &used_refs) {
                    entity.update_task_id(ref_id);
                    used_refs.insert(ref_id);
                } else {
                    // Optional relation was missing in reference pool
                }
                entity.update_action(format!("{} {}", "Sample", i + 1));

                entity.update_detail(format!("{} {}", "Sample", i + 1));





entity.audit_as("Init Sample Data").save(ctx.user_context()).await.map_err(|e| e.to_string())?;

        state.record_generated("Task Execution Log");

        if i % 20 == 0 {
            log::info!("Generating Task Execution Log: {}/{}", i, fanout);
        }
    }

    log::info!("Successfully generated sample records for Task Execution Log.");
    Ok(())
}